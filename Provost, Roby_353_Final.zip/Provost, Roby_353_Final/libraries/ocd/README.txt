Installation Notes

1. Unzip/expand the package and copy the OCD folder into the �processing/libraries� folder.
2. Restart Processing if currently open, and import the "OCD" library from the application's menu �Sketch -> Import Library -> ocd�. 